import json, pandas as pd
s=open('/mnt/user-data/uploads/index.html',encoding='utf-8').read()
i=s.find('const DATA=')+len('const DATA=')
D,_=json.JSONDecoder().raw_decode(s[i:])
V,A,T,W=D['V'],D['A'],D['T'],D['W']
cols=['계열','직무유형','산업','업무영역','요구학력','경력구간','최소연차','고용형태','회사명','공고제목','URL','기업규모','종업원수구간','연봉최소','연봉최대','kw','시도','직무코드','att','sk','본문']
rows=[dict(zip(cols,r)) for r in D['rows']]
for k,r in enumerate(rows): r['공고ID']=f'P{k+1:04d}'
def grp(e): return '신입~3년' if e in('신입','1~3년') else ('4년차+' if e in('4~6년','7+') else '기타')
post=pd.DataFrame([{ '공고ID':r['공고ID'],'산업':r['산업'],'계열':r['계열'],'직무유형':r['직무유형'],'경력구간':r['경력구간'],
  '연차묶음':grp(r['경력구간']),'신입가능':int(r['경력구간'] in('신입','경력 무관')),'고용형태':r['고용형태'],
  '고용형태명시':int(r['고용형태']!='미기재'),'정규직':int(r['고용형태']=='정규직'),
  '본문있음':int(r['본문']==1),'태도본문있음':int(r['att'] is not None),
  '회사명':r['회사명'],'공고제목':r['공고제목'],'URL':r['URL']} for r in rows])
post.to_csv('ind_postings.csv',index=False,encoding='utf-8-sig')
cntind={k:sum(1 for r in rows if r['산업']==k) for k in set(r['산업'] for r in rows)}
dom=pd.DataFrame([{'공고ID':r['공고ID'],'산업':r['산업'],'산업_공고수':cntind[r['산업']],'업무영역':d} for r in rows for d in (r['업무영역'] or [])])
dom.to_csv('ind_domains.csv',index=False,encoding='utf-8-sig')
# keyword rates (wide)
inds=sorted(set(r['산업'] for r in rows))
def rate(rs):
    b=[r for r in rs if r['본문']==1]; c=[0]*len(V)
    for r in b:
        for j in r['kw']: c[j]+=1
    return len(b),c
nA,cA=rate(rows)
kw=[];bund=[]
cats=list(dict.fromkeys(v[1] for v in V))
for ind in inds:
    rs=[r for r in rows if r['산업']==ind]
    n,c=rate(rs)
    nj,cj=rate([r for r in rs if grp(r['경력구간'])=='신입~3년'])
    ns,cs=rate([r for r in rs if grp(r['경력구간'])=='4년차+'])
    for j,(nm,cat) in enumerate(V):
        kw.append({'산업':ind,'키워드':nm,'키워드묶음':cat,'산업_건수':c[j],'산업_분모':n,'전체_건수':cA[j],'전체_분모':nA,
                   '신입3년_건수':cj[j],'신입3년_분모':nj,'4년차_건수':cs[j],'4년차_분모':ns})
    for cat in cats:
        js=[j for j,v in enumerate(V) if v[1]==cat]
        k=sum(1 for r in rs if any(j in js for j in r['kw']))
        top=[V[j][0] for j in sorted([j for j in js if c[j]],key=lambda j:-c[j])[:3]]
        if k: bund.append({'산업':ind,'키워드묶음':cat,'건수':k,'분모':n,'대표키워드':'·'.join(top)})
pd.DataFrame(kw).to_csv('ind_kw_rates.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(bund).to_csv('ind_bundles.csv',index=False,encoding='utf-8-sig')
# attitude
def att(rs):
    b=[r for r in rs if r['att'] is not None]; return len(b),[sum(1 for r in b if i in r['att']) for i in range(len(A))]
nAA,cAA=att(rows); at=[]
for ind in inds:
    n,c=att([r for r in rows if r['산업']==ind])
    for i,a in enumerate(A): at.append({'산업':ind,'표현':a,'산업_건수':c[i],'산업_분모':n,'전체_건수':cAA[i],'전체_분모':nAA})
pd.DataFrame(at).to_csv('ind_att_rates.csv',index=False,encoding='utf-8-sig')
# wage tenure
wt=[]
for key,v in T.items():
    if key in('tenures','occ'): continue
    for o,(t,r) in enumerate(zip(T['tenures'],v)):
        wt.append({'기준':key,'근속':t,'근속순서':o+1,'평균':r[0],'하위25':r[1],'중위':r[2],'상위25':r[3],'카드라벨':r[4] or None})
pd.DataFrame(wt).to_csv('wage_tenure.csv',index=False,encoding='utf-8-sig')
wi=[{'산업':k,'매핑신뢰도':w['conf'],'기준산업':w.get('basis'),'대분류':w.get('major'),'산업_정규직평균':w.get('reg'),'전산업_정규직평균':w.get('treg'),'차이_pct':w.get('pct')} for k,w in W.items()]
pd.DataFrame(wi).to_csv('wage_industry.csv',index=False,encoding='utf-8-sig')
print('T keys',[k for k in T if k not in('tenures','occ')])
print('inds',inds); print('W missing',[x for x in inds if x not in W])
p=post[post.산업=='플랫폼']; print(len(p),p.신입가능.sum(),round(p.신입가능.mean()*100,1),round(p.정규직.sum()/p.고용형태명시.sum()*100,1),p.고용형태명시.sum())
print(dom[dom.산업=='플랫폼'].업무영역.value_counts().head(5))
a=pd.DataFrame(at);print(a[a.산업=='플랫폼'].head(3))
print(round(post.신입가능.mean()*100,1))
# summary sentences (HTML 로직 그대로)
FK=['엔지니어링','분석','모델링','거버넌스']
summ=[]
for ind in inds:
    rs=[r for r in rows if r['산업']==ind]; n=len(rs)
    fam={k:sum(1 for r in rs if r['계열']==k) for k in FK}; tk=max(FK,key=lambda k:fam[k])
    nk,ck=rate(rs)
    order=sorted([j for j in range(len(V)) if ck[j]],key=lambda j:-ck[j])
    lift=None
    if nk>=10:
        cand=[j for j in range(len(V)) if ck[j]>=max(3,nk*0.05)]
        if cand: lift=max(cand,key=lambda j:(ck[j]/nk)/((cA[j] or 1)/nA))
    s1=f"{tk} 계열 공고가 {fam[tk]/n*100:.0f}%로 가장 많다." if fam[tk] else '직무 계열이 확인된 공고가 없다.'
    s2=(f"가장 많이 나온 역량은 {V[order[0]][0]}({ck[order[0]]/nk*100:.0f}%)"+(f", {V[order[1]][0]}({ck[order[1]]/nk*100:.0f}%)" if len(order)>1 else '')+'이다.') if order else '역량 키워드가 확인된 공고가 없다.'
    L=(ck[lift]/nk)/((cA[lift] or 1)/nA) if lift is not None else 0
    s3=f"전체보다 유독 많은 역량은 {V[lift][0]}으로 전체 데이터 공고의 {L:.1f}배다." if L>=1.3 else '전체와 비교해 두드러지게 많은 역량은 없다.'
    si=sum(1 for r in rs if r['경력구간'] in('신입','경력 무관')); sa=post.신입가능.sum()
    s4=f"신입 가능 공고는 {si/n*100:.1f}%로 전체 평균 {sa/len(rows)*100:.1f}%보다 {'높다' if si/n>sa/len(rows) else '낮다'}."
    top5=order[:5]
    a_=[cj_[j]/nj_*100 if nj_ else 0 for j in top5] if False else None
    nj_,cj_=rate([r for r in rs if grp(r['경력구간'])=='신입~3년']); ns_,cs_=rate([r for r in rs if grp(r['경력구간'])=='4년차+'])
    r1=[(V[j][0],(cj_[j]/nj_*100 if nj_ else 0),(cs_[j]/ns_*100 if ns_ else 0)) for j in top5]
    if r1:
        mj=max(r1,key=lambda x:x[1]-x[2]); ms=max(r1,key=lambda x:x[2]-x[1])
        t1=f"신입~3년은 {mj[0]}, 4년차+는 {ms[0]}" if mj!=ms else '연차별 역량 차이'
    else: t1='연차별 역량 차이'
    na,ca=att(rs)
    if na:
        ti=max(range(len(A)),key=lambda i:(ca[i],-i))
        hi=[A[i] for i in sorted(range(len(A)),key=lambda i:-ca[i]) if na>=30 and ca[i]>=3 and (ca[i]/na)/(cAA[i]/nAA)>=1.3]
        ta=f"가장 많이 나온 표현은 {A[ti]} {ca[ti]}건({ca[ti]/na*100:.0f}%)이다. "+(f"전체보다 1.3배 이상 자주 나오는 표현은 {', '.join(hi)}다." if hi else '전체보다 1.3배 이상 자주 나오는 표현은 없다.')
    else: ta=''
    summ.append({'산업':ind,'공고수':n,'요약1':s1,'요약2':s2,'요약3':s3,'요약4':s4,'R1제목':t1,'R1_신입3년_n':nj_,'R1_4년차_n':ns_,'태도요약':ta})
pd.DataFrame(summ).to_csv('ind_summary.csv',index=False,encoding='utf-8-sig')
print(pd.DataFrame(summ).query("산업=='플랫폼'").T)
print(post[post.산업=='플랫폼'].계열.value_counts())
